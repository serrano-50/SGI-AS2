# sesion.py para gaurdar temporalmente el codigo de incio de sesion
User = None
rol = None
